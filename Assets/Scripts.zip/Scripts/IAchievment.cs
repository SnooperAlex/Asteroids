using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAchievment
{
    void UnlockAchievment(AchievmentsObject achievment);
}
